package cn.frame.test;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

public class SheetTest {

	@org.junit.Test
	public void getDataFromExcel() {
		/*ExportExcel exp=new ExportExcel();
		File file=new File("F:\\myself\\sheet\\Excel-262853066.xls");
		Map<Integer,Map<Integer,String>> list=exp.getExcelInfo(file);
		for(int i=0;i<list.size();i++) {
			UserInformation ui=new UserInformation();
			ui.setRealname(list.get(i).get(1));
			ui.setGender(list.get(i).get(2));
			ui.setBirth(list.get(i).get(3));
			ui.setNation(list.get(i).get(4));
			System.out.println(ui);
		}*/
		String requestUri = "http://localhost:8080/frame/sheet/export.do";		
		HttpPost httpPost = new HttpPost(requestUri);
		//httpPost.setEntity((HttpEntity) file);
		httpPost.setHeader("Content-Type", "application/json;charset=UTF-8");
		CloseableHttpClient httpclient = HttpClients.createDefault();
		try {
			CloseableHttpResponse response = httpclient.execute(httpPost);
			System.out.println(response);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
