package cn.frame.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Test {

	private static String url="jdbc:mysql://localhost:3306/hhl?characterEncoding=utf8&useUnicode=true&autoReconnect=true&serverTimezone=UTC";
	private static String user="root";
	private static String password="root";
	
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	public static Connection getConnection() {
		Connection conn=null;
		try {
			conn=DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	public static void main(String[] args) {
		String sql="select * from user";
		try {
			PreparedStatement stmt=getConnection().prepareStatement(sql);
			ResultSet rs=stmt.executeQuery();
			while(rs.next()) {
				System.out.println(rs.getString("uname"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
