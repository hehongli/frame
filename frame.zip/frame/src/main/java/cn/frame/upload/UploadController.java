package cn.frame.upload;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value = "/file")
public class UploadController {

	@RequestMapping(value = "/upload")
	@ResponseBody
	public ModelAndView upload(@RequestParam(value = "file", required = false) MultipartFile multipartFile,
			HttpServletRequest request, ModelMap map) {
		String message = "";
		FileEntity entity = new FileEntity();
		FileUploadTool fileUploadTool = new FileUploadTool();
		// JSONObject getObj = new JSONObject();
		try {
			entity = fileUploadTool.createFile(multipartFile, request);
			if (entity != null) {
				//service.saveFile(entity);
				message = "�ϴ��ɹ�";
				map.put("entity", entity);
				map.put("result", message);
			} else {
				message = "�ϴ�ʧ��";
				map.put("result", message);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ModelAndView("radio/viewRadio", map);
	}
}
