package cn.frame.service;

import java.util.List;

import cn.frame.entity.User;

public interface UserService {

	public List<User> selectUsers();
	public int insertUsers(User user);
}
