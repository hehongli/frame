package cn.frame.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.frame.dao.UserInformationDao;
import cn.frame.entity.UserInformation;
import cn.frame.service.UserInformationService;

@Service("userInformationService")
public class UserInformationServiceImpl implements UserInformationService {

	@Autowired
	private UserInformationDao userInformationDao;
	
	public List<UserInformation> selectUserInformation() {
		return userInformationDao.selectUserInformation();
	}

	public int insertUserInformations(UserInformation userInformation) {
		return userInformationDao.insertUserInformations(userInformation);
	}

}
