package cn.frame.service;

import java.util.List;

import cn.frame.entity.UserInformation;

public interface UserInformationService {

	public List<UserInformation> selectUserInformation();
	public int insertUserInformations(UserInformation userInformation);
}
