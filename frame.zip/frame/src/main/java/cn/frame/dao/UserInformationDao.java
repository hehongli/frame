package cn.frame.dao;

import java.util.List;

import cn.frame.entity.UserInformation;

public interface UserInformationDao {

	public List<UserInformation> selectUserInformation();
	public int insertUserInformations(UserInformation userInformation);
}
