package cn.frame.entity;

import java.util.Date;

public class UserInformation {

	private String uid;
	private String realname;
	private String gender;
	private String birth;
	private String nation;
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getRealname() {
		return realname;
	}
	public void setRealname(String realname) {
		this.realname = realname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public String getNation() {
		return nation;
	}
	public void setNation(String nation) {
		this.nation = nation;
	}
	@Override
	public String toString() {
		return "UserInformation [uid=" + uid + ", realname=" + realname + ", gender=" + gender + ", birth=" + birth
				+ ", nation=" + nation + "]";
	}
}
