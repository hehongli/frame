package cn.frame.datatransmission;

import java.io.File;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.frame.entity.User;
import cn.frame.entity.UserInformation;
import cn.frame.service.UserInformationService;
import cn.frame.service.UserService;

@Controller
@RequestMapping("/sheet")
public class ReportFormController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private UserInformationService userInformationService;
	
	@RequestMapping("/import")
	public void test() {
		  String title = "manifestIExportTitle";
          String[] rowsName = new String[]{"序号","用户编号","用户名","用户密码","注册时间"};
          List<Object[]>  dataList = new ArrayList<Object[]>();
          List<User> users=userService.selectUsers();
          Object[] objs = null;
          for (int i = 0; i < users.size(); i++) {
              User user = users.get(i);
              objs = new Object[rowsName.length];
              objs[0] = i;
              objs[1] = user.getUid();
              objs[2] = user.getUname();
              objs[3] = user.getPassword();
              SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
              String date = df.format(user.getAddtime());
              objs[4] = date;
              dataList.add(objs);
          }
          ImportExcel ex = new ImportExcel(title, rowsName, dataList);
          try {
			ex.export();
			System.out.println("导入成功");
		} catch (Exception e) {
			System.out.println("导入失败");
			e.printStackTrace();
		}
	}
	
	@RequestMapping("/export")
	public void exportDataFromExcel() {
		 ExportExcel readExcel=new ExportExcel();
		 File file=new File("F:\\myself\\sheet\\Excel-262853066.xls");
		 //获取excel中日期样式
		 DecimalFormat df = new DecimalFormat("#");
	     //解析excel，获取上传的事件单  
		 Map<Integer,Map<Integer,String>> list=readExcel.getExcelInfo(file);
	     //至此已经将excel中的数据转换到list里面了,接下来就可以操作list,可以进行保存到数据库,或者其他操作,  
	     //和你具体业务有关,这里不做具体的示范  
	     if(list != null && !list.isEmpty()){  
	    	 for(int i=0;i<list.size();i++) {
	    		 UserInformation ui=new UserInformation();
	    		 ui.setRealname(list.get(i).get(1));
	    		 ui.setGender(df.format(list.get(i).get(2)));
	    		 ui.setBirth(list.get(i).get(3));
	    		 ui.setNation(list.get(i).get(4));
	    		 userInformationService.insertUserInformations(ui);
	    	 }
	         System.out.println("导出成功"); 
	     }else{  
	    	 System.out.println("导出成功"); 
	     }  
	}
}
