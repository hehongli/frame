package frame;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/test")
public class Test {

	@RequestMapping("/hello")
	public void returnText(HttpServletResponse response) {
		try {
			response.getWriter().println("���");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
